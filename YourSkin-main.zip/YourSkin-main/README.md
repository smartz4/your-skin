# Getting Started

Open Project in Android Studio and change ip_address URL in package com.exanple.yourskin on these file

	1.ListURL.java
  
	2.ApiSkincare.java
